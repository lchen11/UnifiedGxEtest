rm(list=ls())
library(MASS)

ncase = 3000
ncontrol = 3000

MAF = 0.2
Pe = 0.5
significance.level = 1/100000

beta_GE = log(1.3)
beta_G = 0
beta_E = 0
prevalence = 0.05

n = 10000       # the number of replications

######################################################################
#   Part I. The function to obtain the optimal filtering threshold   #
######################################################################

# This function is for binary E in case-control studies, which is the setting in the simulations and application section

optimal <- function(k,k1,beta_G,beta_E,beta_GE,MAF){
  
  ## ===== (1) Get alpha for the full logistic regression model based on prevalence ===== ##
  
  x <- c(1:10000)/10000
  risk_calculate <- x/(1+x)*(1-Pe)*(1-MAF)^2 +
    x*exp(beta_G)/(1+x*exp(beta_G))*(1-Pe)*2*MAF*(1-MAF) +
    x*exp(2*beta_G)/(1+x*exp(2*beta_G))*(1-Pe)*MAF^2 +
    x*exp(beta_E)/(1+x*exp(beta_E))*Pe*(1-MAF)^2 + 
    x*exp(beta_E+beta_G+beta_GE)/(1+x*exp(beta_E+beta_G+beta_GE))*Pe*2*MAF*(1-MAF) +
    x*exp(beta_E+2*beta_G+2*beta_GE)/(1+x*exp(beta_E+2*beta_G+2*beta_GE))*Pe*MAF^2
  alpha <- log(x[abs(prevalence-risk_calculate) == min(abs(prevalence-risk_calculate))])
  
  bb = c(alpha,beta_G,beta_E,beta_GE)
  
  ## ===== (2) Obtain the distribution of testing statistics, Zj's ===== ##
  
  R <- function(E,G){
    return(exp(c(1,G,E,G*E)%*%bb)/(1+exp(c(1,G,E,G*E)%*%bb)))
  }
  
  p1_case <- R(0,0)*(1-Pe)*(1-MAF)^2/prevalence
  p2_case <- R(0,1)*(1-Pe)*2*MAF*(1-MAF)/prevalence
  p3_case <- R(0,2)*(1-Pe)*MAF^2/prevalence
  p4_case <- R(1,0)*(Pe)*(1-MAF)^2/prevalence
  p5_case <- R(1,1)*(Pe)*2*MAF*(1-MAF)/prevalence
  p6_case <- R(1,2)*(Pe)*MAF^2/prevalence
  
  p1_control <- (1-R(0,0))*(1-Pe)*(1-MAF)^2/(1-prevalence)
  p2_control <- (1-R(0,1))*(1-Pe)*2*MAF*(1-MAF)/(1-prevalence)
  p3_control <- (1-R(0,2))*(1-Pe)*MAF^2/(1-prevalence)
  p4_control <- (1-R(1,0))*(Pe)*(1-MAF)^2/(1-prevalence)
  p5_control <- (1-R(1,1))*(Pe)*2*MAF*(1-MAF)/(1-prevalence)
  p6_control <- (1-R(1,2))*(Pe)*MAF^2/(1-prevalence)
  
  p1 <- p1_case*(ncase/(ncase+ncontrol))+p1_control*(ncontrol/(ncase+ncontrol))
  p2 <- p2_case*(ncase/(ncase+ncontrol))+p2_control*(ncontrol/(ncase+ncontrol))
  p3 <- p3_case*(ncase/(ncase+ncontrol))+p3_control*(ncontrol/(ncase+ncontrol))
  p4 <- p4_case*(ncase/(ncase+ncontrol))+p4_control*(ncontrol/(ncase+ncontrol))
  p5 <- p5_case*(ncase/(ncase+ncontrol))+p5_control*(ncontrol/(ncase+ncontrol))
  p6 <- p6_case*(ncase/(ncase+ncontrol))+p6_control*(ncontrol/(ncase+ncontrol))
  
  meanYgivenE0G0 <- exp(alpha)/(1+exp(alpha))*(1-Pe)*(1-MAF)^2/prevalence*(ncase/(ncase+ncontrol))/p1
  newalpha <- log(meanYgivenE0G0/(1-meanYgivenE0G0))
  
  newbb <- c(newalpha,beta_G,beta_E,beta_GE)
  R2 <- function(E,G){
    return(exp(c(1,G,E,G*E)%*%newbb)/(1+exp(c(1,G,E,G*E)%*%newbb))^2)
  }
  
  I1 <- R2(0,0)*p1+R2(0,1)*p2+R2(0,2)*p3+R2(1,0)*p4+R2(1,1)*p5+R2(1,2)*p6
  I2 <- R2(0,1)*p2+2*R2(0,2)*p3+R2(1,1)*p5+2*R2(1,2)*p6
  I3 <- R2(1,0)*p4+R2(1,1)*p5+R2(1,2)*p6
  I4 <- R2(1,1)*p5+2*R2(1,2)*p6
  I5 <- R2(0,1)*p2+4*R2(0,2)*p3+R2(1,1)*p5+4*R2(1,2)*p6
  I6 <- R2(1,1)*p5+2*R2(1,2)*p6
  I7 <- R2(1,1)*p5+4*R2(1,2)*p6
  I8 <- R2(1,2)*p4+R2(1,1)*p5+R2(1,2)*p6
  I9 <- R2(1,1)*p5+2*R2(1,2)*p6
  I10 <- R2(1,1)*p5+4*R2(1,2)*p6
  
  I <- matrix(c(I1, I2, I3, I4, I2, I5, I6, I7, I3, I6, I8, I9, I4, I7, I9, I10), ncol=4)
  mu <- beta_GE*sqrt(ncase+ncontrol)/sqrt(solve(I)[4,4])
  
  ## ===== (3) Obtain the distribution of filtering statistics, Xj's ===== ##
  
  beta_0 <- log(p4/p1)
  beta <- log(p5/p2)-beta_0
  a <- beta_0
  b <- beta
  I_a <- (1-MAF)^2*exp(a)/(1+exp(a))^2 + 2*MAF*exp(a+b)/(1+exp(a+b))^2 + MAF^2*exp(a+2*b)/(1+exp(a+2*b))^2
  I_ab <- 2*MAF*exp(a+b)/(1+exp(a+b))^2 + MAF^2*exp(a+2*b)/(1+exp(a+2*b))^2*2
  I_b <- 2*MAF*exp(a+b)/(1+exp(a+b))^2 + MAF^2*exp(a+2*b)/(1+exp(a+2*b))^2*4
  I_theta <- matrix(c(I_a,I_ab,I_ab,I_b),ncol=2)
  V <- solve(I_theta)
  V_b <- V[2,2]
  se_b <- sqrt(V_b)/sqrt(ncase+ncontrol)
  mu_prime <- beta/se_b
  
  ## ===== (4) Get optimal threshold by maxizing the approximated power ===== ##
  
  mu1 <- mu
  mu2 <- mu_prime   # Empirically, these (m1 and mu2) are around the right scale, as a function of beta_GE
  eta <- c(c(1:1000)/10000,c(11:100)/100)
  eta1 <- pnorm(qnorm(eta/2)+mu2) + pnorm(qnorm(eta/2)-mu2)      
  
  k0=k-k1
  s0 = k*eta*(2*eta^2-9*eta+15)/(k*(3*eta-eta^2))^(3/2)/sqrt(8)
  B0 = 1/s0^2
  A0 = sqrt(k*(3*eta-eta^2)/(2*B0))
  C0 = k*eta-eta*2*k*(3-eta)^2/(2*eta^2-9*eta+15)
  
  Var_Talternative = k0*(3*eta-eta^2)+k1*(eta1*(3+6*mu^2+mu^4)-eta1^2*(1+mu^2)^2)
  ThreeCumulant = 15*k0*eta-9*k0*eta^2+2*k0*eta^3+k1*(mu^6+15*mu^4+45*mu^2+15)*eta1-3*k1*(1+mu^2)*(3+6*mu^2+mu^4)*eta1^2+2*k1*(1+mu^2)^3*eta1^3
  s1 = ThreeCumulant/Var_Talternative^(3/2)/sqrt(8)
  B1 = 1/s1^2
  A1 = sqrt(Var_Talternative/(2*B1))
  C1 = k0*eta+k1*eta1*(1+mu^2)-A1*B1
  
  power_function <- 1-pchisq(A0/A1*qchisq((1-significance.level),B0,0)+(C0-C1)/A1,B1,0)
  opt <- eta[power_function==max(power_function)]
  return(c(opt[length(opt)],mu,mu_prime))
}


threshold_alpha = 1/100000     # the significance threshold after controling for multiple testing
mu <- optimal(6,2,beta_G,beta_E,beta_GE,MAF)[2]
mu_prime <- optimal(6,2,beta_G,beta_E,beta_GE,MAF)[3]

##############################################################
#   Part II. Simulate power with fixed filtering thresholds  #
##############################################################

Power.fixed <- function(k,k1,eta){    
  k0=k-k1
  pvalue <- rep(NA,n)
  
  for (i in 1:n){
    set.seed(i)
    Z <- mvrnorm(1,c(rep(mu,k1),rep(0,k0)),diag(1,k))
    X <- mvrnorm(1,c(rep(mu_prime,k1),rep(0,k0)),diag(1,k))
    T_alternative <- sum(Z^2*(abs(X)>qnorm((1-eta/2),0,1)))
    df <- sum((abs(X)>qnorm((1-eta/2),0,1)))
    pvalue[i] <- 1-pchisq(T_alternative,df,0)
  }
  
  return(mean(pvalue<threshold_alpha))
}

##################################################################
#   Part III. Simulate power using various filtering thresholds  #
##################################################################

Power <- function(k,k1,opt_eta){   
  k0=k-k1
  eta <- c(1,0.9,0.8,0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.19,0.18,0.17,0.16,0.15,0.14,0.13,0.12,0.11,0.1, 0.09,0.08,0.07,0.06,0.05,0.04, 0.03, 0.02,0.01,0.009,0.008,0.007,0.006,0.005,0.0054,0.003,0.002,0.001,0.0001,opt_eta)
  
  ## ===== (1) Simulate the null distributions of Z and X ===== ##
  
  set.seed(1)
  X_null <- matrix(rnorm(k*1000000,0,1),nrow=1000000)
  Z_null <- matrix(rnorm(k*1000000,0,1),nrow=1000000)
  
  ## ===== (2) Get power for each filtering threshold being considered ===== ##
  
  pvalue <- matrix(NA,ncol=length(eta),nrow=n)
  
  for (j in 1:length(eta)){
    #print(j)
    threshold <- eta[j]
    T_null <- rep(NA,nrow(Z_null))
    for (l in 1:nrow(Z_null)){
      T_null[l] <- sum(Z_null[l,]^2*(abs(X_null[l,])>qnorm(1-threshold/2,0,1)))
    }
    
    for (i in 1:n){
      set.seed(i)
      Z <- mvrnorm(1,c(rep(mu,k1),rep(0,k0)),diag(1,k))
      X <- mvrnorm(1,c(rep(mu_prime,k1),rep(0,k0)),diag(1,k))
      T_alternative <- sum(Z^2*(abs(X)>qnorm((1-threshold/2),0,1)))
      pvalue[i,j] <- mean(T_alternative <= T_null)
    }
  }
  
  return(colMeans(pvalue<threshold_alpha))
  
}


## Only need to change the following part to simulate power for different k and k1

# This is the proposed filtering threshold using different k and k1
optimal.100.2 <- optimal(k=100,k1=2,beta_G,beta_E,beta_GE,MAF)[1]
optimal.100.5 <- optimal(k=100,k1=5,beta_G,beta_E,beta_GE,MAF)[1]
optimal.100.8 <- optimal(k=100,k1=8,beta_G,beta_E,beta_GE,MAF)[1]

# This is the power of the proposed method using different filtering thresholds
simulate.power <- Power(k = 100,k1 = 5,opt_eta = c(optimal.100.2,optimal.100.5,optimal.100.8))
max(simulate.power)
simulate.power

# This is the power with a fixed filtering threshold = 0.1, considering only the SNPs that passed filtering
Power.fixed(k=100,k1=5,eta=0.1)
