rm(list=ls())
library(MASS)
library(popgen)
library(data.table)


######################################################################
#   Part I. The function to obtain the optimal filtering threshold   #
######################################################################

# This function is for binary E in case-control studies, which is the setting in the simulations and application section

optimal <- function(k,beta_G,beta_E,beta_GE,MAF){
  
  ## ===== (1) Get alpha for the full logistic regression model based on prevalence ===== ##
  
  x <- c(1:10000)/10000
  risk_calculate <- x/(1+x)*(1-Pe)*(1-MAF)^2 +
    x*exp(beta_G)/(1+x*exp(beta_G))*(1-Pe)*2*MAF*(1-MAF) +
    x*exp(2*beta_G)/(1+x*exp(2*beta_G))*(1-Pe)*MAF^2 +
    x*exp(beta_E)/(1+x*exp(beta_E))*Pe*(1-MAF)^2 + 
    x*exp(beta_E+beta_G+beta_GE)/(1+x*exp(beta_E+beta_G+beta_GE))*Pe*2*MAF*(1-MAF) +
    x*exp(beta_E+2*beta_G+2*beta_GE)/(1+x*exp(beta_E+2*beta_G+2*beta_GE))*Pe*MAF^2
  alpha <- log(x[abs(prevalence-risk_calculate) == min(abs(prevalence-risk_calculate))])
  
  bb = c(alpha,beta_G,beta_E,beta_GE)
  
  ## ===== (2) Obtain the distribution of testing statistics, Zj's ===== ##
  
  R <- function(E,G){
    return(exp(c(1,G,E,G*E)%*%bb)/(1+exp(c(1,G,E,G*E)%*%bb)))
  }
  
  p1_case <- R(0,0)*(1-Pe)*(1-MAF)^2/prevalence
  p2_case <- R(0,1)*(1-Pe)*2*MAF*(1-MAF)/prevalence
  p3_case <- R(0,2)*(1-Pe)*MAF^2/prevalence
  p4_case <- R(1,0)*(Pe)*(1-MAF)^2/prevalence
  p5_case <- R(1,1)*(Pe)*2*MAF*(1-MAF)/prevalence
  p6_case <- R(1,2)*(Pe)*MAF^2/prevalence
  
  p1_control <- (1-R(0,0))*(1-Pe)*(1-MAF)^2/(1-prevalence)
  p2_control <- (1-R(0,1))*(1-Pe)*2*MAF*(1-MAF)/(1-prevalence)
  p3_control <- (1-R(0,2))*(1-Pe)*MAF^2/(1-prevalence)
  p4_control <- (1-R(1,0))*(Pe)*(1-MAF)^2/(1-prevalence)
  p5_control <- (1-R(1,1))*(Pe)*2*MAF*(1-MAF)/(1-prevalence)
  p6_control <- (1-R(1,2))*(Pe)*MAF^2/(1-prevalence)
  
  p1 <- p1_case*(ncase/(ncase+ncontrol))+p1_control*(ncontrol/(ncase+ncontrol))
  p2 <- p2_case*(ncase/(ncase+ncontrol))+p2_control*(ncontrol/(ncase+ncontrol))
  p3 <- p3_case*(ncase/(ncase+ncontrol))+p3_control*(ncontrol/(ncase+ncontrol))
  p4 <- p4_case*(ncase/(ncase+ncontrol))+p4_control*(ncontrol/(ncase+ncontrol))
  p5 <- p5_case*(ncase/(ncase+ncontrol))+p5_control*(ncontrol/(ncase+ncontrol))
  p6 <- p6_case*(ncase/(ncase+ncontrol))+p6_control*(ncontrol/(ncase+ncontrol))
  
  meanYgivenE0G0 <- exp(alpha)/(1+exp(alpha))*(1-Pe)*(1-MAF)^2/prevalence*(ncase/(ncase+ncontrol))/p1
  newalpha <- log(meanYgivenE0G0/(1-meanYgivenE0G0))
  
  newbb <- c(newalpha,beta_G,beta_E,beta_GE)
  R2 <- function(E,G){
    return(exp(c(1,G,E,G*E)%*%newbb)/(1+exp(c(1,G,E,G*E)%*%newbb))^2)
  }
  
  I1 <- R2(0,0)*p1+R2(0,1)*p2+R2(0,2)*p3+R2(1,0)*p4+R2(1,1)*p5+R2(1,2)*p6
  I2 <- R2(0,1)*p2+2*R2(0,2)*p3+R2(1,1)*p5+2*R2(1,2)*p6
  I3 <- R2(1,0)*p4+R2(1,1)*p5+R2(1,2)*p6
  I4 <- R2(1,1)*p5+2*R2(1,2)*p6
  I5 <- R2(0,1)*p2+4*R2(0,2)*p3+R2(1,1)*p5+4*R2(1,2)*p6
  I6 <- R2(1,1)*p5+2*R2(1,2)*p6
  I7 <- R2(1,1)*p5+4*R2(1,2)*p6
  I8 <- R2(1,2)*p4+R2(1,1)*p5+R2(1,2)*p6
  I9 <- R2(1,1)*p5+2*R2(1,2)*p6
  I10 <- R2(1,1)*p5+4*R2(1,2)*p6
  
  I <- matrix(c(I1, I2, I3, I4, I2, I5, I6, I7, I3, I6, I8, I9, I4, I7, I9, I10), ncol=4)
  mu <- beta_GE*sqrt(ncase+ncontrol)/sqrt(solve(I)[4,4])
  
  ## ===== (3) Obtain the distribution of filtering statistics, Xj's ===== ##
  
  beta_0 <- log(p4/p1)
  beta <- log(p5/p2)-beta_0
  a <- beta_0
  b <- beta
  I_a <- (1-MAF)^2*exp(a)/(1+exp(a))^2 + 2*MAF*exp(a+b)/(1+exp(a+b))^2 + MAF^2*exp(a+2*b)/(1+exp(a+2*b))^2
  I_ab <- 2*MAF*exp(a+b)/(1+exp(a+b))^2 + MAF^2*exp(a+2*b)/(1+exp(a+2*b))^2*2
  I_b <- 2*MAF*exp(a+b)/(1+exp(a+b))^2 + MAF^2*exp(a+2*b)/(1+exp(a+2*b))^2*4
  I_theta <- matrix(c(I_a,I_ab,I_ab,I_b),ncol=2)
  V <- solve(I_theta)
  V_b <- V[2,2]
  se_b <- sqrt(V_b)/sqrt(ncase+ncontrol)
  mu_prime <- beta/se_b
  
  ## ===== (4) Get optimal threshold by maxizing the approximated power ===== ##
  
  mu1 <- mu
  mu2 <- mu_prime   # Empirically, these (m1 and mu2) are around the right scale, as a function of beta_GE
  eta <- c(c(1:1000)/10000,c(11:100)/100)
  eta1 <- pnorm(qnorm(eta/2)+mu2) + pnorm(qnorm(eta/2)-mu2)      
  
  k0=k-k1
  s0 = k*eta*(2*eta^2-9*eta+15)/(k*(3*eta-eta^2))^(3/2)/sqrt(8)
  B0 = 1/s0^2
  A0 = sqrt(k*(3*eta-eta^2)/(2*B0))
  C0 = k*eta-eta*2*k*(3-eta)^2/(2*eta^2-9*eta+15)
  
  Var_Talternative = k0*(3*eta-eta^2)+k1*(eta1*(3+6*mu^2+mu^4)-eta1^2*(1+mu^2)^2)
  ThreeCumulant = 15*k0*eta-9*k0*eta^2+2*k0*eta^3+k1*(mu^6+15*mu^4+45*mu^2+15)*eta1-3*k1*(1+mu^2)*(3+6*mu^2+mu^4)*eta1^2+2*k1*(1+mu^2)^3*eta1^3
  s1 = ThreeCumulant/Var_Talternative^(3/2)/sqrt(8)
  B1 = 1/s1^2
  A1 = sqrt(Var_Talternative/(2*B1))
  C1 = k0*eta+k1*eta1*(1+mu^2)-A1*B1
  
  power_function <- 1-pchisq(A0/A1*qchisq((1-significance.level),B0,0)+(C0-C1)/A1,B1,0)
  opt <- eta[power_function==max(power_function)]
  return(opt[length(opt)])
}




###########################################################################################
#   Part II. Simulate power using various filtering thresholds in Figure 1 and Figure 2   #
###########################################################################################

n = 100000       # the number of replications
threshold_alpha = 1/100000     # the significance threshold after controling for multiple testing

# Before applying the below "Power" function
# (1) Specifiy mu and mu_prime based on sample size and GxE effect sizes
# (2) Obtain the proposed filtering threshold, opt_eta, using the above "optimal" function
# (3) Here, the frequency of the environmental exposure is 0.5, and the disease prevalence is 0.05

Power <- function(k,k1,opt_eta){   
  k0=k-k1
  eta <- c(1,0.9,0.8,0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.17,0.15,0.13,0.12,0.11,0.1, 0.09,0.08,0.07,0.06,0.05,0.04, 0.03, 0.02,0.01,0.009,0.008,0.007,0.006,0.005,0.004,0.003,0.002,0.001,0.0005,0.0001,opt_eta)
  
  ## ===== (1) Simulate the null distributions of Z and X ===== ##
  
  set.seed(1)
  X_null <- matrix(rnorm(k*1000000,0,1),nrow=1000000)
  Z_null <- matrix(rnorm(k*1000000,0,1),nrow=1000000)
  
  ## ===== (2) Get power for each filtering threshold being considered ===== ##
  
  pvalue <- matrix(NA,ncol=length(eta),nrow=n)
  
  for (j in 1:length(eta)){
    
    threshold <- eta[j]
    T_null <- rep(NA,nrow(Z_null))
    for (l in 1:nrow(Z_null)){
      T_null[l] <- sum(Z_null[l,]^2*(abs(X_null[l,])>qnorm(1-threshold/2,0,1)))
    }
    
    for (i in 1:n){
      set.seed(i)
      Z <- mvrnorm(1,c(rep(mu,k1),rep(0,k0)),diag(1,k))
      X <- mvrnorm(1,c(rep(mu_prime,k1),rep(0,k0)),diag(1,k))
      #Z <- mvrnorm(1,c(c(3.603024,2.538474,4.535252),rep(0,k0)),diag(1,k))
      #X <- mvrnorm(1,c(c(3.73287,2.581437,4.801919),rep(0,k0)),diag(1,k))
      T_alternative <- sum(Z^2*(abs(X)>qnorm((1-threshold/2),0,1)))
      pvalue[i,j] <- mean(T_alternative <= T_null)
    }
  }
  
  return(colMeans(pvalue<threshold_alpha))
  
}



###########################################
#   Part III. Analyze PanScan GWAS data   #
###########################################

## ===== (1) Define a function to get test statsitics from linear probability model efficiently ===== ##

ols <- function (y, x) { 
  x <- cbind(1,x)
  x <- as.matrix(x)
  xy <- t(x)%*%y 
  xxi <- solve(t(x)%*%x) 
  b <- as.vector(xxi%*%xy)
  se <- sqrt(diag(xxi)*var(y-x%*%b))
  return(b/se)
} 


## ===== (2) Read the genotype data for a chromosome (take chromosome 1 as an example here) ===== ##

load(file="snp_index_chr1_reduced.RData")
oo <- fread("chr1_reduced.raw",nrows=5900)

## ===== (3) Read Y, E and covariates for the 5805 subjects ===== ##

cov <- read.table(file="covar12.txt",header=T)
id_in_genotype <- unlist(oo[,2,with=F],use.names=F)
cov <- cov[match(id_in_genotype,cov[,2]),]
E <- cov[,3]-1
Pe <- 0.5
E <- E-mean(E)
Y <- cov[,4]-1

## ==== (4) Specify the parameters for calculating the proposed filtering threshold ===== ##

k1 <- 3 
ncase <- sum(Y==1)
ncontrol <- sum(Y==0)
prevalence <- 0.01
significance.level <- 0.1/10000

## ===== (5) The main part for gene-based tests ===== ##

pvalue_chr1 <- NULL
gene.size.after.prune <- NULL
optimal.filteirng.threshold <- NULL

for (l in 1:length(snp_index_chr1_reduced)){
  
  set.seed(l)
  
  index <- 6+snp_index_chr1_reduced[[l]]  ##  the first 6 columns are not genotype
  G <- as.matrix(oo[,index,with=F])
  
  LD <- LDmat(G,typ="genotype",plotmat=F)
  LD.prune.list <- NULL
  for (i in 1:(ncol(LD)-1)){
    if ((i %in% LD.prune.list)==FALSE){
      for (j in (i+1):ncol(LD))
        if (LD[j,i]>0.9) {LD.prune.list <- c(LD.prune.list,j)} ## the lower triangle is R2
    }
  }
  prune.index<- c(1:ncol(LD))[c(1:ncol(LD)) %in% LD.prune.list]
  gene.size.after.prune[l] <- ncol(LD)-length(prune.index)
  print(c(l,gene.size.after.prune[l]))
  
  if (ncol(LD)-length(prune.index)<5) {
    pvalue_chr1[l] <- -9
    optimal.filteirng.threshold[l] <- -9
  }else{
    if (length(prune.index)>0) G <- G[,-prune.index]
    MAF <- mean((colSums(G)+1)/(2*5805+1))
    G <- G - rep(1, nrow(G)) %*% t(colMeans(G))  ## center G
    k <- ncol(G)
    threshold <- optimal(k,beta_G=0,beta_E=log(1.2),beta_GE=log(1.3),MAF)
    optimal.filteirng.threshold[l] <- threshold
    
    X <- apply(G,2,function(x){return(ols(E,cbind(cov[,5:9],cov[,16:19],x))[11])})
    Z <- apply(G,2,function(x){return(ols(Y,cbind(cov[,5:9],cov[,16:19],E,x,E*x))[13])})
    T <- sum(Z^2*(abs(X)>qnorm((1-threshold/2),0,1)))
    
    ## Calculate p-values with the sequential sampling strategy
    
    if (T==0) {
      pvalue_chr1[l] <- 1
    }else {
      corG <- cor(G)
      X_null <- mvrnorm(n = 100, rep(0,ncol(G)), corG)
      Z_null <- mvrnorm(n = 100, rep(0,ncol(G)), corG)
      T_null <- lapply(1:100,function(x){return(sum(Z_null[x,]^2*(abs(X_null[x,])>qnorm((1-threshold/2),0,1))))})
      p <- mean(unlist(T_null)>=T)    
      if (p >= 0.1){
        pvalue_chr1[l] <- p
      }else{
        X_null <- mvrnorm(n = 1000, rep(0,ncol(G)), corG)
        Z_null <- mvrnorm(n = 1000, rep(0,ncol(G)), corG)
        T_null <- lapply(1:1000,function(x){return(sum(Z_null[x,]^2*(abs(X_null[x,])>qnorm((1-threshold/2),0,1))))})
        p <- mean(unlist(T_null)>=T)    
        if (p >= 0.01){
          pvalue_chr1[l] <- p
        }else{
          X_null <- mvrnorm(n = 10000, rep(0,ncol(G)), corG)
          Z_null <- mvrnorm(n = 10000, rep(0,ncol(G)), corG)
          T_null <- lapply(1:10000,function(x){return(sum(Z_null[x,]^2*(abs(X_null[x,])>qnorm((1-threshold/2),0,1))))})
          p <- mean(unlist(T_null)>=T)    
          if (p >= 0.001){
            pvalue_chr1[l] <- p
          }else{
            X_null <- mvrnorm(n = 100000, rep(0,ncol(G)), corG)
            Z_null <- mvrnorm(n = 100000, rep(0,ncol(G)), corG)
            T_null <- lapply(1:100000,function(x){return(sum(Z_null[x,]^2*(abs(X_null[x,])>qnorm((1-threshold/2),0,1))))})
            p <- mean(unlist(T_null)>=T)    
            if (p >= 0.0001){
              pvalue_chr1[l] <- p
            }else{
              X_null <- mvrnorm(n = 1000000, rep(0,ncol(G)), corG)
              Z_null <- mvrnorm(n = 1000000, rep(0,ncol(G)), corG)
              T_null <- lapply(1:1000000,function(x){return(sum(Z_null[x,]^2*(abs(X_null[x,])>qnorm((1-threshold/2),0,1))))})
              pvalue_chr1[l] <- mean(unlist(T_null)>=T)
            }
          }
        } 
      }
    }
  }
  print(c(optimal.filteirng.threshold[l],pvalue_chr1[l]))
}

save(pvalue_chr1,gene.size.after.prune, optimal.filteirng.threshold, file="result_chr1.RData")