## Simulate genotypes of SNPs in LD using a gene from PanScan Data
## Please read "xx.common.ped", "xx.common.map" and "xx.common.LD"

rm(list=ls())
library(MASS)

k=100
nsample = 2000   # Sample size in the study

oo <- read.table(file="NCAM2.common.ped")
haplotypes <- oo[,7:ncol(oo)]
map <- read.table(file="NCAM2.common.map")

## Prune SNPs in high LD (R-square > 0.9)
LD <- read.table(file="NCAM2.common.LD")
LD.prune.list <- NULL
for (i in 1:(ncol(LD)-1)){
  if ((i %in% LD.prune.list)==FALSE){
    for (j in (i+1):ncol(LD))
      if (LD[i,j]>0.9) {LD.prune.list <- c(LD.prune.list,j)}
  }
}
prune.index<- c(1:ncol(LD))[c(1:ncol(LD)) %in% LD.prune.list]
LD.after.prune <- LD[-prune.index,-prune.index]
dim(LD.after.prune)

##========== Simulate genotypes =============##

haplotypes.after.pruning <- haplotypes[,-c((prune.index-1)*2+1,(prune.index-1)*2+2)]
H1 <- as.matrix(haplotypes.after.pruning[,c(1:k)*2-1])
H2 <- as.matrix(haplotypes.after.pruning[,c(1:k)*2])
H <- rbind(H1,H2)
maf <- 1-colMeans(H-1)   # In H, minor allele is 1, major allele is2
mean(maf)
H <- (H==1)*1+(H==2)*0

get.geno <- function(seed){
  set.seed(seed)
  ind <- sample(1:11610,2)
  return(colSums(H[ind,]))
}

geno <- lapply(c(1:nsample),get.geno)
G <- matrix(unlist(geno),byrow=T,ncol=k)    