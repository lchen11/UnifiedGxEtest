## Assume effect sizes, MAF, Pr(E) are known
rm(list=ls())
set.seed(1)

k=100
k1=3
alpha1=0.1

## Input MAF, effect sizes (beta_G, beta_E, beta_GE), Pr(E); get alpha2 as a function of alpha1
mu <- 3
mu_prime <- 2    # Empirically, these (m1 and mu2) are around the right scale, as a function of beta_GE
alpha2 <- pnorm(qnorm(alpha1/2)+mu_prime) + pnorm(qnorm(alpha1/2)-mu_prime)              

  # Exact mixture of chi-square distributions

    B_null <- rbinom(100000,k,alpha1)
    T_null <- rep(0,length(B_null))
    T_null[B_null>0] <- sapply(B_null[B_null>0],function(B_null) return(rchisq(1,B_null,0)))
    #T_null[is.na(T_null)] = 0
    # alpha quantile of T0
    B1 <- rbinom(100000,k-k1,alpha1)
    B2 <- rbinom(100000,k1,alpha2)
    obs1 <- rep(0,length(B1))
    obs2 <- rep(0,length(B2))
    obs1[B1>0] <- sapply(B1[B1>0],function(B1) return(rchisq(1,B1,0)))
    #obs1[is.na(obs1)] <- 0
    obs2[B2>0] <- sapply(B2[B2>0],function(B2) return(rchisq(1,B2,(mu)^2*B2)))
    #obs2[is.na(obs2)] <- 0
    T_alternative <- obs1+obs2
  
  # approximation 3 cumulants matching
  k0=k-k1
  s0 = k*alpha1*(2*alpha1^2-9*alpha1+15)/(k*(3*alpha1-alpha1^2))^(3/2)/sqrt(8)
  B0 = 1/s0^2
  A0 = sqrt(k*(3*alpha1-alpha1^2)/(2*B0))
  C0 = k*alpha1-alpha1*2*k*(3-alpha1)^2/(2*alpha1^2-9*alpha1+15)
  
  Var_Talternative = k0*(3*alpha1-alpha1^2)+k1*(alpha2*(3+6*mu^2+mu^4)-alpha2^2*(1+mu^2)^2)
  ThreeCumulant = 15*k0*alpha1-9*k0*alpha1^2+2*k0*alpha1^3+k1*(mu^6+15*mu^4+45*mu^2+15)*alpha2-3*k1*(1+mu^2)*(3+6*mu^2+mu^4)*alpha2^2+2*k1*(1+mu^2)^3*alpha2^3
  s1 = ThreeCumulant/Var_Talternative^(3/2)/sqrt(8)
  B1 = 1/s1^2
  A1 = sqrt(Var_Talternative/(2*B1))
  C1 = k0*alpha1+k1*alpha2*(1+mu^2)-A1*B1

T_null_approx <- A0*rchisq(100000,B0,0)+C0
T_alternative_approx <- A1*rchisq(100000,B1,0)+C1

qqplot(T_null,T_null_approx,xlab="(a) T under the null", ylab="The approximated distribution",pch=20,cex=0.5)
T_null <- sort(T_null)
index <- c(1:length(T_null))[T_null==0]
qqplot(T_null[-index],sort(T_null_approx)[-index],xlab="(a) T under the null", ylab=expression(paste(A[0],chi[B[0]]^2,(0),+C[0])),pch=20,cex=0.8,mgp=c(2.5,1,0))
abline(0,1)

qqplot(T_alternative,T_alternative_approx,xlab="(b) T under the alternative", ylab="The approximated distribution",pch=20,cex=0.4)
T_alternative <- sort(T_alternative)
T_alternative_approx <- sort(T_alternative_approx)
index <- c(1:length(T_alternative))[T_alternative==0]
qqplot(T_alternative[-index],T_alternative_approx[-index],xlab="(b) T under the alternative", ylab=expression(paste(A[1],chi[B[1]]^2,(0),+C[1])),pch=20,cex=0.8,mgp=c(2.5,1,0),ylim=c(0,90))
abline(0,1)



d_Tnull <- density(T_null,adjust=2) # returns the density data
plot(d_Tnull,col="red",xlim=c(1,80),lwd=1.5,xlab="Test statistic",main=" ")
d_Tnull_approx <- density(T_null_approx,adjust=2) # returns the density data
lines(d_Tnull_approx,col="blue",lwd=1.5)
d_Talternative <- density(T_alternative,adjust=2) # returns the density data
lines(d_Talternative,col="red",lty="dotted",lwd=2)
d_Talternative_approx <- density(T_alternative_approx,adjust=2) # returns the density data
lines(d_Talternative_approx,col="blue",lty="dotted",lwd=2)

legend(20,0.08, lty=1,"T under the null",bty="n",col="red",lwd=1.5,cex=0.9)
legend(20,0.071, lty=1,expression(paste(A[0],chi[B[0]]^2,(0),+C[0])),bty="n",col="blue",lwd=1.5,cex=0.9)
legend(20,0.059, lty=3,"T under the alternative",bty="n",col="red",lwd=2,cex=0.9)
legend(20,0.05, lty=3,expression(paste(A[1],chi[B[1]]^2,(0),+C[1])),bty="n",col="blue",lwd=2,cex=0.9)