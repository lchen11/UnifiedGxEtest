rm(list=ls())
library(MASS)
set.seed(1)

## Given mu, mu_prime, k, k1, cor(Z) and cor(X)

mu <- 4
mu_prime <- 3
threshold_alpha <- 0.01/1000
k1=3
k=30
k0=k-k1

## 10 SNPs in LD, 29 indep - 30 indep SNPs

## one of the causal SNP is in LD with others

n = 10000      # replications
alpha1 <- c(1.000, 0.900, 0.800, 0.700, 0.600, 0.500, 0.400, 0.3, 0.200, 0.170, 0.130, 0.120, 0.100, 0.090, 0.080, 0.050, 0.040, 0.030, 0.020, 0.010, 0.007, 0.005, 0.003)
# Simulate null distributions of Z and X
set.seed(1)
X_null <- matrix(rnorm(k*10000000,0,1),nrow=10000000)
Z_null <- matrix(rnorm(k*10000000,0,1),nrow=10000000)


# Power
pvalue <- matrix(NA,ncol=length(alpha1),nrow=n)
weight <- c(5,rep(1,28),5)    # two LD blocks; one with a causal variants; the other one without


for (j in 1:length(alpha1)){
  print(j)
  set.seed(j)
  threshold <- alpha1[j]
  T_null <- lapply(c(1:nrow(Z_null)),function(x){return(sum(weight*Z_null[x,]^2*(abs(X_null[x,])>qnorm(1-threshold/2,0,1))))})
  T_null <- unlist(T_null)
  Z <- mvrnorm(n,c(rep(mu,k1),rep(0,k0)),diag(1,k))
  X <- mvrnorm(n,c(rep(mu_prime,k1),rep(0,k0)),diag(1,k))
  T_alternative <- lapply(c(1:nrow(Z)),function(x){return(sum(weight*Z[x,]^2*(abs(X[x,])>qnorm(1-threshold/2,0,1))))})
  T_alternative <- unlist(T_alternative)
  pvalue[,j] <- unlist(lapply(c(1:length(T_alternative)),function(x){return(mean(T_alternative[x] <= T_null))}))
  print(mean(pvalue[,j]<threshold_alpha))
}

power_LD <- colMeans(pvalue<threshold_alpha)